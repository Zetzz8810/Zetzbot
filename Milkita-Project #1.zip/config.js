const fs = require('fs')

global.namabot = "ZetzBotMD"
global.namaowner = "ZKing"
global.packname = "©ZetzzBot"
global.creator = "Z-Team"
global.author = "Ardy"
global.wm = "Zetz"
global.myweb = "https://zetzz.my.id"
global.footer_text = "©Zetz "
global.owner = ['6281239621820']
global.doc = "ᴍɪʟᴋɪᴛᴀ ᴍᴜʟᴛɪᴅᴇᴠɪᴄᴇ"
//===============================
global.apikey = '8c3a5b302815a138d88148fa0c5916c0595bba50' //ambil dari web ini https://otpweb.com
//==================================
global.qris = "https://-"
global.dana = "081239621820"
global.gopay = "081239621820"
global.rek = "7605-0101-8289-536"
//================================
global.fake = "https://telegra.ph/file/55df8393d102d69ead186.jpg"
global.gifin = "https://telegra.ph/file/00224f1c0b07a10555f09.mp4"
global.news = "𝙕𝙚𝙩𝙯𝘽𝙤𝙩𝙈𝘿|©ᴢᴇᴛᴢᴀᴜᴛᴏʀᴇsᴘᴏɴᴛʙᴏᴛ"
global.syt = "https://www.youtube.com/@imzetzz"
global.sgc = "https://"
global.email = "ɴᴜʀʀ67813@gmail.com"
global.sig = "https://Instagram.com/@-"
//==========================
global.pairingNumber = "6281239621820" 
global.prefa = ['.']
global.tekspushcontact = "Izin Push"
global.typemenu = "v1"
global.grup_only = true 
global.antispam = true
global.auto_record = true
global.anticall = true
global.gcount = {
     prem: 1000,
     user: 20,
}
global.mess = {
    done: '_Success_',
    wait: '_Sedang Di Proses_',
    admin: '_Fitur Khusus Admin Group_',
    botNotAdmin: '_Jadikan Bot Sebagai Admin Terlebih Dahulu_',
    owner: '_Fitur Khusus Owner Bot_',
    group: '_Fitur Khusus Dalam Group_',
}

