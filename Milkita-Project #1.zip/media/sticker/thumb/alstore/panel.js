const domain = '' //isi domain mu
const apikey = '' //apikey plta
const capikey = '' //apikey pltc
const eggsnya = '15' 
const location = '1' 

module.exports = { domain, apikey, capikey, eggsnya, location }

